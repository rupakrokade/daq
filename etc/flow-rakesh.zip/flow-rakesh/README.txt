
Here are the steps to perform the test:
1. Change the working directory to the one in which you have copied the step test folder
2. Execute ser_init.sce after changing the port number to the port corresponding to SBHS
3. Execute step_test.sci
4. Open Xcos
5. Run step_test.xcos
